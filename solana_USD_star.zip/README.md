# Solana USD* Token & NUMERATIVE AMM Analyzer

This is the combined CLI + Web app version.