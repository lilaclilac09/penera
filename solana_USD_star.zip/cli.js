// cli.js - Entry point for cli
