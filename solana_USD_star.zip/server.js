// server.js - Entry point for server
